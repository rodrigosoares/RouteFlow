""" rfhavox_topo topology

author: Rodrigo Soares (rodrigosoares@id.uff.br)

Four switches connected in grid topology plus a host for each switch. A remote
host is connected to other two adjacent neighbors.
Each host is intended to run a Quagga instance as if each was a different AS.

       h1 --- s1 ---- s2 --- h2
               |       |       \
               |       |        \
               |       |         h5
               |       |        /
               |       |       /
       h3 --- s3 ---- s4 --- h4

AS 1 (main) = s1, s2, s3 and s4
AS 1000     = h1
AS 2000     = h2
AS 3000     = h3
AS 4000     = h4
AS 5000     = h5

"""

import inspect
import os
from mininext.topo import Topo
from mininext.services.quagga import QuaggaService
from collections import namedtuple

QuaggaHost = namedtuple('QuaggaHost', 'name ip lo gw')


class rfhavox_topo(Topo):
    'RouteFlow demo setup with Havox support for Mininext'

    def __init__(self):
        Topo.__init__(self)

        self_path = os.path.dirname(os.path.abspath(
            inspect.getfile(inspect.currentframe())
        ))

        quagga_svc = QuaggaService(autoStop=False)

        quagga_base_config_path = self_path + '/configs/'

        quagga_hosts = []
        quagga_hosts.append(QuaggaHost(name='h1',
                                       ip='172.31.1.100/24',
                                       lo='10.0.1.1/24',
                                       gw='gw 172.31.1.1'))
        quagga_hosts.append(QuaggaHost(name='h2',
                                       ip='172.31.2.100/24',
                                       lo='10.0.2.1/24',
                                       gw='gw 172.31.2.1'))
        quagga_hosts.append(QuaggaHost(name='h3',
                                       ip='172.31.3.100/24',
                                       lo='10.0.3.1/24',
                                       gw='gw 172.31.3.1'))
        quagga_hosts.append(QuaggaHost(name='h4',
                                       ip='172.31.4.100/24',
                                       lo='10.0.4.1/24',
                                       gw='gw 172.31.4.1'))
        quagga_hosts.append(QuaggaHost(name='h5',
                                       ip='172.32.1.2/30',
                                       lo='10.0.5.1/24',
                                       gw='gw 172.32.1.1'))
        hosts = {}

        for host in quagga_hosts:
            quagga_container = self.addHost(name=host.name,
                                            ip=host.ip,
                                            defaultRoute=host.gw,
                                            hostname=host.name,
                                            privateLogDir=True,
                                            privateRunDir=True,
                                            inMountNamespace=True,
                                            inPIDNamespace=True,
                                            inUTSNamespace=True)
            hosts[host.name] = quagga_container

            self.addNodeLoopbackIntf(node=host.name, ip=host.lo)

            quagga_svc_config = \
                {'quaggaConfigPath': quagga_base_config_path + host.name}
            self.addNodeService(node=host.name, service=quagga_svc,
                                nodeConfig=quagga_svc_config)

        s1 = self.addSwitch('s1')
        s2 = self.addSwitch('s2')
        s3 = self.addSwitch('s3')
        s4 = self.addSwitch('s4')

        self.addLink(hosts['h1'], s1)
        self.addLink(hosts['h2'], s2)
        self.addLink(hosts['h3'], s3)
        self.addLink(hosts['h4'], s4)

        self.addLink(s1, s2)
        self.addLink(s2, s4)
        self.addLink(s4, s3)
        self.addLink(s3, s1)

        self.addLink(hosts['h2'], hosts['h5'], 1, 0)
        self.addLink(hosts['h4'], hosts['h5'], 1, 1)


topos = {'rfhavox_topo': (lambda: rfhavox_topo())}
